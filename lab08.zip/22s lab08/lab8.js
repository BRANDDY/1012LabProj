/* 1012a22s JavaScript code for lab8 */
/* Add your Java Script Code Here */

function problemA(){

 var p = document.getElementById("mydata");

  
 var input1 = parseInt(prompt("enter number m: "));
 var input2 = parseInt(prompt("enter number n: "));
 var resu = multiply(input1, input2);
 p.innerHTML= ... resu;  // generate output as shown in pdf
}

// a recursive function. no loop should be used
function multiply(m, n){
	 

}



function problemB(){

 var p = document.getElementById("mydata");

 var input = parseInt(prompt("enter number: "));

 var resu = count37(input);
 
 p.innerHTML= ... resu;  // generate output as shown in pdf

}

// a recursive function. no loop should be used
function count37(num){
	 
	
}

 

function problemC(){

 var p = document.getElementById("mydata");

 var arr=[7, 3, 5, 9, 8, 6, 1, 4]; 

 var sum0 = arraySum0(arr);
 
 var sum = arraySum(arr, 0);

 p.innerHTML= arr + " sum is: " + sum0 + " " + sum;

}

function arraySum0(arr){
	if ( arr.length == 1)   // or  if(arr.length==0) return 0;
		return arr[0];
	return arr[0] + arraySum0(arr.slice(1));
	
}

// a recursive function. no loop should be used
function arraySum(arr, index){
	 
	
}


function problemD(){

 var p = document.getElementById("mydata");

 var arr=[7, 3, 5, 9, 8, 6, 1, 4]; 

 var max0 = arrayMaxIterative(arr);
 
 var max1 =  arrayMaxRecursiveA(arr);

 var max2 =  arrayMaxRecursiveB(arr, 0);
 
 p.innerHTML= arr + " max is: " + max0 + " " + max1 + " " + max2;

}

// iterative function. use loop
function arrayMaxIterative(arr){
	 

}

// a recursive function. no loop should be used
// pass arr only.    
function arrayMaxRecursiveA(arr){
	 
}

// a recursive function. no loop should be used
// pass arr and a sliding index    
function arrayMaxRecursiveB(arr, index){
	 
}


function problemE()
{
  var p = document.getElementById("mydata");

  var input = prompt("enter string to be reversed: ");

  var resu = reverse(input)
  p.innerHTML= input + " <--> " + resu;

}
function reverse(s){
	 

}
  
function problemF(){

	var arr=[8, 9, 9, 12, 13, 13, 13, 15, 20, 100, 100, 101, 123, 129, 300, 330, 390, 400, 403, 407];
	var key = parseInt(prompt("enter search key for " + arr));	
	
	var p = document.getElementById("mydata");
	
	var resu = findit(key, arr, 0, arr.length-1);
	
    // output results as shown in pdf

}

// a recursive function. no loop should be used
function findit(x, A, i, j){
	 

}

function problemG(){
	var p = document.getElementById("mydata");
	
	var str = prompt("enter string: ");
	 
	
	var resu = symmetric(str, 0, str.length-1);

	// output results as shown in pdf


}	
function symmetric(s, i , j){
	 
	 
	  
}
